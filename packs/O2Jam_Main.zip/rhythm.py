import pygame


pygame.init()

WINDOW = (800, 600)

screen = pygame.display.set_mode((WINDOW))
clock = pygame.time.Clock()
color = (255, 255, 255)

img_note = pygame.image.load("img/Note_BG.png")
img_note = pygame.transform.scale(img_note, (200, 600))
img_play = pygame.image.load("img/Playing_BG10.png")
img_play = pygame.transform.scale(img_play, (600, 560))
img_menu = pygame.image.load("img/Playing_Menu.png")
img_menu = pygame.transform.scale(img_menu, (600, 40))

playing = True
while playing:
    screen.fill(color)
    screen.blit(img_note, (0, 0))
    screen.blit(img_play, (200, 0))
    screen.blit(img_menu, (200, 560))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            playing = False
            pygame.quit()
    pygame.display.flip()
    clock.tick(60)
